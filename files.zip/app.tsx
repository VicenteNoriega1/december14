import { App } from "@openai/toolkit";

// Define the tool that returns the current time
const getCurrentTimeTool = {
  name: "get_current_time",
  description: "Returns the current time in ISO 8601 format",
  // No parameters needed for this simple tool
  parameters: {
    type: "object",
    properties: {},
    required: [],
  },
};

// Tool implementation - returns current time from system clock
function getCurrentTime(): string {
  return new Date().toISOString();
}

// Create and configure the app
const app = new App({
  // Define available tools that the model can call
  tools: [getCurrentTimeTool],
  
  // Handle tool execution when the model decides to call them
  async onToolCall(toolCall) {
    if (toolCall.name === "get_current_time") {
      const currentTime = getCurrentTime();
      
      return {
        result: currentTime,
      };
    }
    
    throw new Error(`Unknown tool: ${toolCall.name}`);
  },
});

// Export the app as default for the Apps SDK runtime
export default app;